class MyStaticData{
  static List<Map<String, String>> people = [
    {
      'name': 'Sosena Abebe',
      'jobTitle': 'Back-End Developer',
      'description': 'Sosena Abebe is a Software developer intern at Amazon in London. She has achieved several awards and is a well-known back-end developer.',
    },
    {
      'name': 'Elias Tadesse',
      'jobTitle': 'Front-End Developer',
      'description': 'Elias Tadesse is a Front-End Developer at Google in San Francisco. He specializes in creating beautiful and responsive user interfaces.',
    },
    {
      'name': 'Hana Melaku',
      'jobTitle': 'Web Developer',
      'description': 'Hana Melaku is a Web Developer at Microsoft in Seattle. She has a passion for developing scalable web applications and has worked on numerous high-profile projects.',
    },
    {
      'name': 'Mulugeta Ayele',
      'jobTitle': 'Full Stack Developer',
      'description': 'Mulugeta Ayele is a Full Stack Developer at Facebook in New York. He is known for his expertise in both front-end and back-end technologies.',
    },
    {
      'name': 'Biruk Haile',
      'jobTitle': 'Front-End Developer',
      'description': 'Biruk Haile is a Front-End Developer at LinkedIn in Mountain View. He excels at building intuitive and dynamic web experiences.',
    },
    {
      'name': 'Mekdes Alemu',
      'jobTitle': 'Back-End Developer',
      'description': 'Mekdes Alemu is a Back-End Developer at Uber in San Francisco. She has a strong background in server-side programming and database management.',
    },
    {
      'name': 'Abebe Tsegaye',
      'jobTitle': 'Web Developer',
      'description': 'Abebe Tsegaye is a Web Developer at IBM in Austin. He is dedicated to creating robust and secure web applications.',
    },
    {
      'name': 'Tsehay Tekle',
      'jobTitle': 'Full Stack Developer',
      'description': 'Tsehay Tekle is a Full Stack Developer at Airbnb in Boston. She has a comprehensive understanding of both client-side and server-side development.',
    },
    {
      'name': 'Fitsum Kebede',
      'jobTitle': 'Front-End Developer',
      'description': 'Fitsum Kebede is a Front-End Developer at Adobe in San Jose. He is proficient in HTML, CSS, and JavaScript, and loves crafting seamless user experiences.',
    },
    {
      'name': 'Banchi Alem',
      'jobTitle': 'Back-End Developer',
      'description': 'Banchi Alem is a Back-End Developer at Oracle in Redwood City. She has extensive knowledge in backend frameworks and cloud services.',
    }
  ];

}