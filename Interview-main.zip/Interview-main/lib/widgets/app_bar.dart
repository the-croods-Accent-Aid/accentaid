import 'package:flutter/material.dart';

class MyAppBar extends StatefulWidget {
  const MyAppBar({super.key, required this.title, required this.hasProfile});
  final String title;
  final bool hasProfile;

  @override
  State<MyAppBar> createState() => _MyAppBarState();
}

class _MyAppBarState extends State<MyAppBar> {
  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: Size.fromHeight(150.0),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 18.0, vertical: 8.0),
        color: Colors.white,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(child: Row(
              children: [
                IconButton(
                  onPressed: (){

                  },
                  icon: Icon(Icons.arrow_back_sharp,color: Colors.black,),
                ),
                Text(widget.title,
                  style: TextStyle(
                      color: Color(0XFF1B6CFC)
                  ),
                )
              ],
            )),
            widget.hasProfile == true ?
              Align(
                alignment: Alignment.centerRight,
                child: InkWell(
                  // child: CircleAvatar(
                  //   backgroundImage: NetworkImage(
                  //
                  //   ),
                  //   radius: 30,
                  // ),
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50)
                    ),
                  ),
                  onTap: () {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //     builder: (context) => ProfileScreen(),
                    //   ),
                    // );
                  },
                ),
              ):SizedBox.shrink()

          ],
        ),
      ),
    );
  }

}
