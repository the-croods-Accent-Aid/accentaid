import 'package:flutter/material.dart';
import 'package:flutter_advanced_avatar/flutter_advanced_avatar.dart';

import '../constants/my_static_data.dart';
import '../pages/chat_screen.dart';
import '../pages/schedule_interview.dart';
class Interviewers extends StatefulWidget {
  const Interviewers({super.key});

  @override
  State<Interviewers> createState() => _InterviewersState();
}

class _InterviewersState extends State<Interviewers> {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
        scrollDirection: Axis.vertical,
        physics: BouncingScrollPhysics(),
        itemCount: MyStaticData.people.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1,
        ),
        itemBuilder: (context, j) {
          return GestureDetector(
            onTap: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ScheduleInterview(),
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Container(
                height: 70,
                width: 70,
                decoration: BoxDecoration(
                  color: Color(0xFFF5F8FF),
                  borderRadius: BorderRadius.all(Radius.circular(30))
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                // child: CircleAvatar(
                //   backgroundImage: NetworkImage(
                //
                //   ),
                //   radius: 30,
                // ),
                      child: ClipOval(
                        child: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(1)
                          ),
                          child: AdvancedAvatar(
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: AssetImage("assets/download2.jpg")
                                )
                            ),
                            statusColor: Colors.blue,
                            statusAlignment: Alignment.topRight,
                            foregroundDecoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(1)
                            ),
                          ),
                        )
                      ),
                      onTap: () {

                      },
                    ),
                    Text(MyStaticData.people[j]['name']!,
                    style: TextStyle(
                      color: Color(0xFF222B45),
                      fontSize: 17
                    ),
                    ),
                    Text(MyStaticData.people[j]['jobTitle']!,
                    style: TextStyle(
                      color: Color(0xFF6B779A),
                      fontSize: 12
                    ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }
}

