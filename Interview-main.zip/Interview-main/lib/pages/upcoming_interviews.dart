import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_image_stack/flutter_image_stack.dart';

import 'interviewer_screen.dart';
import 'live_interview.dart';
class UpcomingInterview extends StatefulWidget {
  const UpcomingInterview({super.key});

  @override
  State<UpcomingInterview> createState() => _UpcomingInterviewState();
}

class _UpcomingInterviewState extends State<UpcomingInterview> {

  @override
  Widget build(BuildContext context) {
    List<String> _images = [
      'assets/download.jpg',
      'assets/download2.jpg'
    ];
    return SafeArea(
      child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(70.0),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              color: Colors.white,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 2,
                    height: 2,
                    color: Colors.transparent,
                  ),
                  Text("Manage Meetings",
                    style: TextStyle(
                        color: Color(0XFF1B6CFC),
                        fontSize: 20,
                        fontWeight: FontWeight.bold
                    )
                  ),
                  Container(
                    width: 2,
                    height: 2,
                    color: Colors.transparent,
                  )
                ]
              )
            )
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 12,),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Upcoming Interviews",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20
                    ),
                    ),
                    SizedBox(height: 7,),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.black.withOpacity(0.25)
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 18.0,
                        horizontal: 12),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Center(
                              child: FlutterImageStack.widgets(
                                  children: [
                                InkWell(
                                  // child: CircleAvatar(
                                  //   backgroundImage: NetworkImage(
                                  //
                                  //   ),
                                  //   radius: 30,
                                  // ),
                                  child: ClipOval(
                                      child: Container(
                                        width: 100,
                                        height: 100,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(image: AssetImage("assets/download2.jpg")),
                                            borderRadius: BorderRadius.circular(100)
                                        ),
                                      )
                                  ),
                                  onTap: () {
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (context) => ProfileScreen(),
                                    //   ),
                                    // );
                                  },
                                ),
                                InkWell(
                                  // child: CircleAvatar(
                                  //   backgroundImage: NetworkImage(
                                  //
                                  //   ),
                                  //   radius: 30,
                                  // ),
                                  child: ClipOval(
                                      child: Container(
                                        width: 100,
                                        height: 100,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(image: AssetImage("assets/download.jpg")),
                                            borderRadius: BorderRadius.circular(100)
                                        ),
                                      )
                                  ),
                                  onTap: () {
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (context) => ProfileScreen(),
                                    //   ),
                                    // );
                                  },
                                )
                              ], totalCount: 2),
                            )
                         ,
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [

                              Text("Behavioral Mock Interview",
                              style: TextStyle(
                                color: Color(0xFF848476)
                              ),
                              ),
                              Text("Tomorrow 11:00 AM",
                                style: TextStyle(
                                    color: Color(0xFFBFBFBF)
                                ),)
                                ],
                              ),
                            ),
                            Container(
                              height: 50,
                              child: ElevatedButton(
                                onPressed: (){
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => LiveInterview(),
                                    ),
                                  );
                                },
                                child: Text(
                                    "Join",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                    )
                                ),
                                style: ButtonStyle(
                                  backgroundColor: MaterialStatePropertyAll(Color(0xFF3E64FF)),
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                  SizedBox(height: 12,),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Upcoming Completed",
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20
                        ),
                      ),
                      SizedBox(height: 7,),
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: Colors.black.withOpacity(0.25)
                            ),
                            borderRadius: BorderRadius.all(Radius.circular(20))
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 18.0,
                              horizontal: 12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Center(
                                child: FlutterImageStack.widgets(
                                    children: [
                                      InkWell(
                                        // child: CircleAvatar(
                                        //   backgroundImage: NetworkImage(
                                        //
                                        //   ),
                                        //   radius: 30,
                                        // ),
                                        child: ClipOval(
                                            child: Container(
                                              width: 100,
                                              height: 100,
                                              decoration: BoxDecoration(
                                                  image: DecorationImage(image: AssetImage("assets/download2.jpg")),
                                                  borderRadius: BorderRadius.circular(100)
                                              ),
                                            )
                                        ),
                                        onTap: () {
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (context) => ProfileScreen(),
                                          //   ),
                                          // );
                                        },
                                      ),
                                      InkWell(
                                        // child: CircleAvatar(
                                        //   backgroundImage: NetworkImage(
                                        //
                                        //   ),
                                        //   radius: 30,
                                        // ),
                                        child: ClipOval(
                                            child: Container(
                                              width: 100,
                                              height: 100,
                                              decoration: BoxDecoration(
                                                  image: DecorationImage(image: AssetImage("assets/download.jpg")),
                                                  borderRadius: BorderRadius.circular(100)
                                              ),
                                            )
                                        ),
                                        onTap: () {
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (context) => ProfileScreen(),
                                          //   ),
                                          // );
                                        },
                                      )
                                    ], totalCount: 2),
                              ),Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    Text("Behavioral Mock Interview",
                                      style: TextStyle(
                                          color: Color(0xFF848476)
                                      ),
                                    ),
                                    Text("Tomorrow 11:00 AM",
                                      style: TextStyle(
                                          color: Color(0xFFBFBFBF)
                                      ),)
                                  ],
                                ),
                              ),
                              Container(
                                height: 50,
                                child: ElevatedButton(
                                  onPressed: (){

                                  },
                                  child: Text(
                                      "Completed",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                      )
                                  ),
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStatePropertyAll(Color(0xFF3E64FF)),
                                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                      RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20.0),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => InterviewerScreen(),
                ),
              );
            },
            tooltip: 'Add Interview',
            child: const Icon(Icons.add),
          )
      ),
    );
  }
}