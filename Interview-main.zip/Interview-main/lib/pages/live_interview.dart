import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'chat_screen.dart';
class LiveInterview extends StatefulWidget {
  const LiveInterview({super.key});

  @override
  State<LiveInterview> createState() => _LiveInterviewState();
}

class _LiveInterviewState extends State<LiveInterview> {

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: PreferredSize(
              preferredSize: Size.fromHeight(70.0),
              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 12,vertical: 5),
                  color: Colors.white,
                  child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          onPressed: (){

                            Navigator.of(context).pop();
                          },
                          icon: Icon(Icons.arrow_back_sharp,color: Colors.black,),
                        ),
                        Text("Live Interview",
                            style: TextStyle(
                                color: Color(0XFF1B6CFC),
                                fontSize: 20,
                                fontWeight: FontWeight.bold
                            )
                        ),
                        Container(
                          width: 2,
                          height: 2,
                          color: Colors.transparent,
                        )
                      ]
                  )
              )
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Behavioral Mock Interview with Abebe",
                          style: TextStyle(
                              color: Color(0XFF6B6B5A),
                              fontSize: 15,
                              fontWeight: FontWeight.bold
                          )
                      ),
                      SizedBox(width: 10),
                      Text("00:01:23",
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xFF333333),
                          fontWeight: FontWeight.bold
                      ),)
                    ],
                  ),
                  SizedBox(height: 12),
                  Container(
                    height: 300,
                    width: 320,
                    decoration: BoxDecoration(
                        image: DecorationImage(image: AssetImage("assets/download3.jpg"))
                    ),
                  ),
                  SizedBox(width: 10),
                  Container(
                      height: 300,
                      width: 400,
                      decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        border: Border.all(color: Colors.grey, width: 1)
                      ),
                      child: ChatScreen()),
                  SizedBox(width: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Color(0xFF1B6CFC),
                            borderRadius: BorderRadius.circular(50)
                        ),
                        child: IconButton(onPressed: (){

                        }, icon: Icon(Icons.video_camera_front_rounded),
                            color: Color(0xFF112B26)),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Color(0xFF1B6CFC),
                            borderRadius: BorderRadius.circular(50)
                        ),
                        child: IconButton(onPressed: (){

                        }, icon: Icon(Icons.mic),
                            color: Color(0xFF112B26)),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Color(0xFF1B6CFC),
                            borderRadius: BorderRadius.circular(50)
                        ),
                        child: IconButton(onPressed: (){

                        }, icon: Icon(Icons.closed_caption),
                            color: Color(0xFF112B26)),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Color(0xFF1B6CFC),
                            borderRadius: BorderRadius.circular(50)
                        ),
                        child: IconButton(onPressed: (){

                        }, icon: Icon(Icons.comment),
                            color: Color(0xFF112B26)),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: Color(0xFFC53937),
                          borderRadius: BorderRadius.circular(50)
                        ),
                        child: IconButton(onPressed: (){

                        }, icon: Icon(Icons.call_end),
                            color: Colors.white),
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
      ),
    );
  }
}