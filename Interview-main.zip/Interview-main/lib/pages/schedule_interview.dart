import 'package:flutter/material.dart';
class ScheduleInterview extends StatefulWidget {
  const ScheduleInterview({super.key});

  @override
  State<ScheduleInterview> createState() => _ScheduleInterviewState();
}

class _ScheduleInterviewState extends State<ScheduleInterview> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(70.0),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              color: Colors.white,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: (){
                      Navigator.of(context).pop();

                    },
                    icon: Icon(Icons.arrow_back_sharp,color: Colors.black,),
                  ),
                  Text("Schedule Interview",
                    style: TextStyle(
                        color: Color(0XFF1B6CFC),
                        fontSize: 20,
                        fontWeight: FontWeight.bold
                    ),
                  ),

                  InkWell(
                    // child: CircleAvatar(
                    //   backgroundImage: NetworkImage(
                    //
                    //   ),
                    //   radius: 30,
                    // ),
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(100)
                      ),
                    ),
                    onTap: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) => ProfileScreen(),
                      //   ),
                      // );
                    },
                  )

                ],
              ),
            ),
          ),
          body: Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 12),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              // child: CircleAvatar(
                              //   backgroundImage: NetworkImage(
                              //
                              //   ),
                              //   radius: 30,
                              // ),
                              child: Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                    color: Colors.red,
                                    borderRadius: BorderRadius.circular(50)
                                ),
                              ),
                              onTap: () {
                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (context) => ProfileScreen(),
                                //   ),
                                // );
                              },
                            ),
                            Text("Sosena Abebe",
                              style: TextStyle(
                                  color: Color(0xFF222B45),
                                  fontSize: 20
                              ),
                            ),
                            Text("Back-end developer",
                              style: TextStyle(
                                  color: Color(0xFF6B779A),
                                  fontSize: 15
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 7),
                    Text("About Interviewer",
                      style: TextStyle(
                          color: Color(0xFF222B45),
                          fontSize: 20
                      ),
                    ),
                    SizedBox(height: 7),
                Text("Sosena Abebe is a Software developer intern at Amazon in London. "
                    "She has achieved several awards and is a well known back-end developer.",
                  style: TextStyle(
                      color: Color(0xFF6B779A),
                      fontSize: 15
                  ),
                ),
                    SizedBox(height: 10,),
                    Container(
                      height: 100,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Color(0xFFF5F8FF),
                          borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [

                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 18.0),
                            child: Text("Working Time",
                              style: TextStyle(
                                  color: Color(0xFF222B45),
                                  fontSize: 20
                              ),
                            ),
                          ),
                          SizedBox(height: 7,),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 18.0),
                            child: Text("Mon - Sat (08:30 AM - 09:00 PM)",
                              style: TextStyle(
                                  color: Color(0xFF6B779A),
                                  fontSize: 12
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Container(
                        height: 100,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: Color(0xFFF5F8FF),
                            borderRadius: BorderRadius.all(Radius.circular(20))
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 18.0),
                              child: Text("Communication",
                                style: TextStyle(
                                    color: Color(0xFF222B45),
                                    fontSize: 20
                                ),
                              ),
                            ),
                            SizedBox(height: 7,),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 18.0),
                              child: Row(
                                children: [
                                  Container(
                                    color: Color(0x26F7C480),
                                    child: IconButton(onPressed: (){

                                    }, icon: Icon(Icons.video_camera_front_rounded),
                                        color: Color(0xFFF7C480)),
                                  ),
                                  Text("Video Call")
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),

                ],
                ),
              ),
            ),
          ),
        bottomNavigationBar:  Container(
          width: double.infinity,
          height: 90,
          padding: EdgeInsets.symmetric(vertical: 10),
          child: ElevatedButton(
            onPressed: (){

            },
            child: Text(
                "Book Interview",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w400,
                    fontFamily: "plusJakartaSans"
                )
            ),
            style: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Color(0xFF3E64FF)),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}