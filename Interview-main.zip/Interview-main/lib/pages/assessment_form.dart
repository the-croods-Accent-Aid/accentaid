import 'package:flutter/material.dart';

import '../layouts/interviewers.dart';
class AssessmentForm extends StatefulWidget {
  const AssessmentForm({super.key});

  @override
  State<AssessmentForm> createState() => _AssessmentFormState();
}

class _AssessmentFormState extends State<AssessmentForm> {

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 12,vertical: 5),
            color: Colors.white,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  onPressed: (){
                    Navigator.of(context).pop();
                  },
                  icon: Icon(Icons.arrow_back_sharp,color: Colors.black,),
                ),
                Text("Assessment Form",
                  style: TextStyle(
                      color: Color(0XFF1B6CFC),
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                Container(
                  width: 2,
                  height: 2
                )
              ],
            ),
          ),
        ),
        body: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                SizedBox(height: 12),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  color: const Color(0xFFF5F8FF),
                  child: TextFormField(
                    textAlignVertical: TextAlignVertical.center,
                    style: TextStyle(
                      color: Color(0x88333333),
                      fontSize: 18,
                    ),
                    decoration: InputDecoration(
                      hintText: "search for interviewers",
                      hintStyle: TextStyle(
                        color: Color(0x88333333),
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                        borderSide: BorderSide.none, // No visible border
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                        borderSide: BorderSide.none, // No visible border
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                        borderSide: BorderSide.none, // No visible border
                      ),
                      isCollapsed: true,
                      isDense: true,
                      prefixIcon: Icon(
                        Icons.search,
                        color: Color(0x88333333),
                        size: 25,
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 0.1),
                    ),
                  ),
                )
                ,
                Interviewers()
              ],
            ),
          ),
        ),
      ),
    );
  }
}
